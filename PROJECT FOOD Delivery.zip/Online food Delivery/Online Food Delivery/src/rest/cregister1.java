package rest;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/cregister1")
public class cregister1 extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
		String n=request.getParameter("name");
		String l=request.getParameter("lname");
		String a=request.getParameter("add");
		String e=request.getParameter("email");
		String p=request.getParameter("pass");
		String m=request.getParameter("mob");
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3308/restaurant", "root", "root");
			PreparedStatement ps=con.prepareStatement("insert into cregister1 values (?,?,?,?,?,?)");
			
			ps.setString(1, n);
			ps.setString(2, l);
			ps.setString(3, a);
			ps.setString(4, e);
			ps.setString(5, m);
			ps.setString(6, p);
			
			ps.executeUpdate();
			
		}catch(Exception e1) {	
			e1.printStackTrace();
		}				
	}
}
